# CS 499 Milestone Two – Software Design and Engineering
**Rajin Ahmed** · Artifact: CS 360 Inventory Management Application (Android / Java / SQLite)

## What's in this ZIP

| Folder | Contents |
|---|---|
| `Original/MyDatabaseApp` | The CS 360 project as it was before the enhancement. Generated build output (`build/`, `.gradle/`, `.idea/`) and the machine-specific `local.properties` were removed; the source code is unchanged. |
| `Enhanced/MyDatabaseApp` | The enhanced project. Open this folder in Android Studio. |
| `Documentation/ENHANCEMENT_NOTES.md` | Before/after comparison, architecture, database schema, pseudocode, test cases, performance measurement plan, and outcome mapping. |

## Files changed or added in the enhanced version

| File | Status | Purpose |
|---|---|---|
| `InventoryItem.java` | **New** | Model for one inventory row (keeps the real database ID) |
| `InventoryAdapter.java` | **New** | Displays `InventoryItem` objects in the list |
| `ValidationUtils.java` | **New** | All input rules in one testable class |
| `PasswordHasher.java` | **New** | Salted PBKDF2 password hashing |
| `DatabaseHelper.java` | Rewritten | Schema v2 with constraints, v1→v2 migration, update/delete by ID, closed cursors, timing logs |
| `InventoryActivity.java` | Rewritten | Validation, edit dialog, delete confirmation, empty state |
| `MainActivity.java` | Rewritten | Validation, duplicate-username handling, hashed login |
| `activity_main.xml`, `activity_inventory.xml` | Updated | Masked password field, titles, instructions, empty-list message |
| `dialog_edit_item.xml` | **New** | Layout for the edit dialog |
| `strings.xml` | Updated | All user-facing text moved to resources |
| `app/build.gradle.kts` | Updated | `minSdk` 24 → 26 (needed for PBKDF2WithHmacSHA256 and `java.util.Base64`), version 2.0 |
| `ValidationUtilsTest.java`, `PasswordHasherTest.java` | **New** | 31 JUnit tests (replace the template `ExampleUnitTest`) |

## How to run
1. Android Studio → **File → Open** → select `Enhanced/MyDatabaseApp`. Let Gradle sync.
2. Run on an emulator (Android 8.0 / API 26 or newer).
3. Unit tests: right-click `app/src/test` → **Run Tests**, or run `gradlew test`.
4. Performance timings: open **Logcat** and filter by the tag `CS499_DB_PERF`.

If the emulator still has the old version of the app installed, the new version upgrades its database automatically (version 1 → 2) and keeps the existing items and accounts.
