# Enhancement Notes – CS 360 Inventory Management Application
CS 499 Milestone Two (Software Design and Engineering) · Rajin Ahmed

These notes answer the Module One feedback, which asked for exact architecture changes, performance measurements, the database schema, test cases, pseudocode or a flowchart, and a mapping to course outcomes.

---

## 1. Problems found in the original code

| # | Original behavior | Why it is a problem |
|---|---|---|
| 1 | `Integer.parseInt(itemQty...)` with no checks | An empty or non-numeric quantity crashed the app (`NumberFormatException`) |
| 2 | Empty item names, usernames, and passwords were accepted | Bad data reached the database |
| 3 | Delete used `db.deleteItem(position + 1)` | List position is not the database ID. After any delete, IDs have gaps, so the wrong item (or nothing) was deleted |
| 4 | No way to edit an item | Inventory apps need updates, not just add/delete |
| 5 | Items were stored in the list as display strings | The database ID was thrown away, which is what caused problem 3 |
| 6 | Passwords stored and compared as plain text | Anyone with the database file could read every password |
| 7 | Password field was not masked | Password visible on screen |
| 8 | Duplicate usernames allowed; failed registration just said "Error" | Confusing for users; login could match the wrong account |
| 9 | Cursors were never closed | Resource leak |
| 10 | `onUpgrade` was empty | Any schema change would break existing installs |
| 11 | Activities contained SQL/cursor logic and hard-coded text | Hard to maintain and test |
| 12 | Only the template unit test existed | No evidence the logic works |

## 2. Architecture changes

**Before:** two activities did everything: read input, build display strings, call the database, and read cursors.

**After:** each class has one job.

```
 MainActivity ─────┐                         ┌── ValidationUtils (input rules, pure Java)
                   ├── uses ─────────────────┤
 InventoryActivity ┘                         ├── DatabaseHelper (all SQL, migration, timing)
        │                                    │        └── PasswordHasher (salt + PBKDF2)
        └── InventoryAdapter ── shows ──> InventoryItem (id, name, quantity)
```

- **UI layer:** `MainActivity`, `InventoryActivity`, `InventoryAdapter`. No SQL, no cursors.
- **Logic layer:** `ValidationUtils`, `PasswordHasher`. No Android dependencies, so they run in plain JUnit tests.
- **Data layer:** `DatabaseHelper` returns `InventoryItem` objects and simple results (`boolean`, `long`, `RegisterResult`).

## 3. Database schema

### Version 1 (original)
```sql
CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT);
CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, quantity INTEGER);
```

### Version 2 (enhanced)
```sql
CREATE TABLE users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  salt          TEXT NOT NULL
);
CREATE TABLE items (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  name     TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity >= 0)
);
CREATE INDEX idx_items_name ON items (name COLLATE NOCASE);
```

### Migration (v1 → v2, runs automatically in `onUpgrade` inside one transaction)
- **users:** each old account is copied with its plain-text password replaced by a salted hash. Blank accounts are dropped. For duplicate usernames, the first account is kept.
- **items:** all rows are copied with their original IDs. Blank names become "Unnamed item", and missing or negative quantities become 0.

The migration SQL was tested against SQLite with deliberately messy version-1 data (duplicates, blanks, negative quantity, ID gaps), and the new constraints rejected invalid inserts.

## 4. Pseudocode

**Login / registration**
```
ON Register:
    error ← validateUsername(username) or validateNewPassword(password)
    IF error: show error on the field; STOP
    IF usernameExists(username): show "username taken"; STOP
    salt ← random 16 bytes
    store username, PBKDF2(password, salt), salt
    show "Account created"

ON Login:
    IF username or password empty: show error; STOP
    row ← SELECT password_hash, salt WHERE username = ?   (case-insensitive)
    IF row exists AND PBKDF2(password, row.salt) == row.password_hash:
        open InventoryActivity
    ELSE:
        show "Invalid username or password"   (same message either way)
    clear password field
```

**Inventory add / update / delete**
```
ON Add:
    validate name (required, ≤ 50 chars) and quantity (whole number, 0–100,000)
    IF invalid: show error on the field; STOP
    id ← INSERT item
    IF id = -1: show "could not save"  ELSE: clear fields, reload list

ON Tap item:
    open edit dialog prefilled with item.name, item.quantity
    ON Save: validate; IF valid: UPDATE items WHERE id = item.id; reload; close dialog
             ELSE keep dialog open and show errors

ON Long-press item:
    ask "Delete <name>?"
    ON confirm: DELETE FROM items WHERE id = item.id; reload list
```

## 5. Test cases

Unit tests (automated, `gradlew test`): **31 tests in `ValidationUtilsTest` and `PasswordHasherTest`.** All passed when run with JUnit 4.13.2.

Manual tests on the emulator. **Fill in the Result column after running them.**

| ID | Steps | Expected result | Result |
|---|---|---|---|
| T1 | Register `tester1` / `secure123` | "Account created" | |
| T2 | Register `tester1` again | Field error "username is already taken" | |
| T3 | Register `ab` / `secure123` | Username length error | |
| T4 | Register `tester2` / `password` | Password must contain a number | |
| T5 | Log in `tester1` / `secure123` | Inventory screen opens | |
| T6 | Log in `tester1` / `wrongpass1` | "Invalid username or password" | |
| T7 | Log in `TESTER1` / `secure123` | Logs in (usernames are case-insensitive) | |
| T8 | Add with empty name | Error on name field; nothing saved | |
| T9 | Add with empty quantity (crashed the original) | Error on quantity field; no crash | |
| T10 | Add "Apples", 25 | Item appears, "Item added" | |
| T11 | Add "Milk", 0 | Shows "Quantity: 0 (out of stock)" | |
| T12 | Tap "Apples", change to 30, Save | List shows 30 | |
| T13 | Tap item, clear the name, Save | Dialog stays open with error | |
| T14 | Add 3 items, delete the first, then long-press the last and delete | The item you long-pressed is the one removed (the original removed the wrong one) | |
| T15 | Long-press, then Cancel | Nothing deleted | |
| T16 | Close the app fully and reopen | Accounts and items are still there | |
| T17 | Delete all items | "No items yet" message shows | |
| T18 | Password field while typing | Characters are masked | |

## 6. Performance measurement

Every database method logs its elapsed time to Logcat under the tag **`CS499_DB_PERF`**, for example:
```
CS499_DB_PERF  addItem took 3.41 ms
CS499_DB_PERF  getAllItems (12 rows) took 1.07 ms
CS499_DB_PERF  authenticate took 410.22 ms
```
**How to record:** run each operation 5 times on the emulator and write down the average.

| Operation | Run 1 | Run 2 | Run 3 | Run 4 | Run 5 | Average (ms) |
|---|---|---|---|---|---|---|
| addItem | | | | | | |
| getAllItems | | | | | | |
| updateItem | | | | | | |
| deleteItem | | | | | | |
| registerUser | | | | | | |
| authenticate | | | | | | |

**Expected trade-off:** `registerUser` and `authenticate` will be much slower than the item operations (hundreds of milliseconds) because PBKDF2 deliberately repeats the hash 120,000 times. That slowness is what makes stolen hashes expensive to crack. It is a security-versus-speed decision, and it is acceptable because it happens only once per login. A future improvement would be to move hashing off the UI thread.

## 7. Course outcome mapping

| Technical result | Program outcome |
|---|---|
| Layered architecture (model, adapter, validation, data layer); update feature; ID-based CRUD; migration path | *Demonstrate an ability to use well-founded and innovative techniques, skills, and tools in computing practices for the purpose of implementing computer solutions that deliver value and accomplish industry-specific goals* |
| Salted PBKDF2 hashing, masked password, parameterized queries, input validation, database constraints, generic login error | *Develop a security mindset that anticipates adversarial exploits in software architecture and designs to expose potential vulnerabilities, mitigate design flaws, and ensure privacy and enhanced security of data and resources* |
| Commented code, README, these notes, unit tests | *Design, develop, and deliver professional-quality oral, written, and visual communications…* (partial; continued in the ePortfolio) |

## 8. Left for later milestones
- **Databases enhancement (Module Five):** link items to the user who owns them (foreign key), add search/filter queries, and add low-stock alerts.
- Run password hashing on a background thread.
