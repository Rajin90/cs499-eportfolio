package com.example.mydatabaseapp;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/** CS 499: unit tests for the input rules (run with: gradlew test). */
public class ValidationUtilsTest {

    // ---- username
    @Test public void username_valid() { assertNull(ValidationUtils.validateUsername("rajin_99")); }
    @Test public void username_trimmed() { assertNull(ValidationUtils.validateUsername("  rajin  ")); }
    @Test public void username_empty() { assertNotNull(ValidationUtils.validateUsername("   ")); }
    @Test public void username_null() { assertNotNull(ValidationUtils.validateUsername(null)); }
    @Test public void username_tooShort() { assertNotNull(ValidationUtils.validateUsername("ab")); }
    @Test public void username_tooLong() { assertNotNull(ValidationUtils.validateUsername("abcdefghijklmnopqrstu")); }
    @Test public void username_badCharacters() { assertNotNull(ValidationUtils.validateUsername("bob'; DROP TABLE users;--")); }

    // ---- new password
    @Test public void password_valid() { assertNull(ValidationUtils.validateNewPassword("secure123")); }
    @Test public void password_empty() { assertNotNull(ValidationUtils.validateNewPassword("")); }
    @Test public void password_tooShort() { assertNotNull(ValidationUtils.validateNewPassword("abc12")); }
    @Test public void password_noDigit() { assertNotNull(ValidationUtils.validateNewPassword("passwordonly")); }
    @Test public void password_noLetter() { assertNotNull(ValidationUtils.validateNewPassword("12345678")); }
    @Test public void loginPassword_onlyRequiresValue() { assertNull(ValidationUtils.validateLoginPassword("x")); }

    // ---- item name
    @Test public void itemName_valid() { assertNull(ValidationUtils.validateItemName("Paper towels")); }
    @Test public void itemName_blank() { assertNotNull(ValidationUtils.validateItemName("  ")); }
    @Test public void itemName_tooLong() {
        assertNotNull(ValidationUtils.validateItemName(new String(new char[51]).replace('\0', 'a')));
    }

    // ---- quantity (the original app crashed on these)
    @Test public void quantity_valid() { assertNull(ValidationUtils.validateQuantity("25")); }
    @Test public void quantity_zeroAllowed() { assertNull(ValidationUtils.validateQuantity("0")); }
    @Test public void quantity_empty() { assertNotNull(ValidationUtils.validateQuantity("")); }
    @Test public void quantity_notNumber() { assertNotNull(ValidationUtils.validateQuantity("ten")); }
    @Test public void quantity_decimal() { assertNotNull(ValidationUtils.validateQuantity("2.5")); }
    @Test public void quantity_negative() { assertNotNull(ValidationUtils.validateQuantity("-3")); }
    @Test public void quantity_tooLarge() { assertNotNull(ValidationUtils.validateQuantity("100001")); }
    @Test public void quantity_overflow() { assertNotNull(ValidationUtils.validateQuantity("99999999999")); }
    @Test public void quantity_parse() { assertEquals(42, ValidationUtils.parseQuantity(" 42 ")); }
}
