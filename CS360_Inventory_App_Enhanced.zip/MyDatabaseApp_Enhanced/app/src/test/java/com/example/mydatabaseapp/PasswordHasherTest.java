package com.example.mydatabaseapp;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/** CS 499: unit tests for password hashing (run with: gradlew test). */
public class PasswordHasherTest {

    @Test
    public void correctPasswordVerifies() {
        String salt = PasswordHasher.generateSalt();
        String hash = PasswordHasher.hash("secure123", salt);
        assertTrue(PasswordHasher.verify("secure123", salt, hash));
    }

    @Test
    public void wrongPasswordFails() {
        String salt = PasswordHasher.generateSalt();
        String hash = PasswordHasher.hash("secure123", salt);
        assertFalse(PasswordHasher.verify("secure124", salt, hash));
    }

    @Test
    public void hashIsNotThePlainPassword() {
        String salt = PasswordHasher.generateSalt();
        assertNotEquals("secure123", PasswordHasher.hash("secure123", salt));
    }

    @Test
    public void samePasswordDifferentSaltsGiveDifferentHashes() {
        String a = PasswordHasher.hash("secure123", PasswordHasher.generateSalt());
        String b = PasswordHasher.hash("secure123", PasswordHasher.generateSalt());
        assertNotEquals(a, b);
    }

    @Test
    public void hashingIsRepeatableForSameSalt() {
        String salt = PasswordHasher.generateSalt();
        assertEquals(PasswordHasher.hash("secure123", salt), PasswordHasher.hash("secure123", salt));
    }

    @Test
    public void nullInputsDoNotVerify() {
        assertFalse(PasswordHasher.verify(null, PasswordHasher.generateSalt(), "abc"));
    }
}
