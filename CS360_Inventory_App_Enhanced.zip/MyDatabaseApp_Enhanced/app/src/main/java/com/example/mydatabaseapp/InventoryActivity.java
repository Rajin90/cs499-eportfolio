package com.example.mydatabaseapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * Inventory screen: add, view, update, and delete items.
 *
 * CS 499 enhancements:
 *  - Input is validated before it reaches the database (no more crash on an
 *    empty or non-numeric quantity).
 *  - Tap an item to edit it (new update feature).
 *  - Long-press asks for confirmation, then deletes by the item's real
 *    database ID instead of "list position + 1".
 *  - Shows a message when the inventory is empty.
 *  - The activity no longer reads Cursors; it works with InventoryItem objects.
 */
public class InventoryActivity extends AppCompatActivity {

    private EditText itemNameInput;
    private EditText itemQtyInput;
    private DatabaseHelper db;
    private InventoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        itemNameInput = findViewById(R.id.itemName);
        itemQtyInput = findViewById(R.id.itemQty);
        Button addBtn = findViewById(R.id.addBtn);
        ListView listView = findViewById(R.id.listView);
        TextView emptyView = findViewById(R.id.emptyView);

        db = new DatabaseHelper(this);
        adapter = new InventoryAdapter(this, new ArrayList<>());
        listView.setAdapter(adapter);
        listView.setEmptyView(emptyView);

        addBtn.setOnClickListener(v -> addItem());

        listView.setOnItemClickListener((parent, view, position, id) -> {
            InventoryItem item = adapter.getItem(position);
            if (item != null) {
                showEditDialog(item);
            }
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            InventoryItem item = adapter.getItem(position);
            if (item != null) {
                confirmDelete(item);
            }
            return true;
        });

        loadItems();
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }

    private void loadItems() {
        adapter.clear();
        adapter.addAll(db.getAllItems());
    }

    private void addItem() {
        String name = itemNameInput.getText().toString();
        String qtyText = itemQtyInput.getText().toString();

        if (!isValid(itemNameInput, name, itemQtyInput, qtyText)) {
            return;
        }

        long newId = db.addItem(name, ValidationUtils.parseQuantity(qtyText));
        if (newId == -1) {
            toast(R.string.error_saving_item);
            return;
        }
        itemNameInput.setText("");
        itemQtyInput.setText("");
        itemNameInput.requestFocus();
        toast(R.string.item_added);
        loadItems();
    }

    private void showEditDialog(InventoryItem item) {
        View form = getLayoutInflater().inflate(R.layout.dialog_edit_item, null);
        EditText nameInput = form.findViewById(R.id.editItemName);
        EditText qtyInput = form.findViewById(R.id.editItemQty);
        nameInput.setText(item.getName());
        qtyInput.setText(String.valueOf(item.getQuantity()));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.edit_item_title)
                .setView(form)
                .setPositiveButton(R.string.save, null) // listener set below so we can keep the dialog open on errors
                .setNegativeButton(R.string.cancel, null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    String name = nameInput.getText().toString();
                    String qtyText = qtyInput.getText().toString();
                    if (!isValid(nameInput, name, qtyInput, qtyText)) {
                        return;
                    }
                    if (db.updateItem(item.getId(), name, ValidationUtils.parseQuantity(qtyText))) {
                        toast(R.string.item_updated);
                        loadItems();
                        dialog.dismiss();
                    } else {
                        toast(R.string.error_saving_item);
                    }
                }));
        dialog.show();
    }

    private void confirmDelete(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_item_title)
                .setMessage(getString(R.string.delete_item_message, item.getName()))
                .setPositiveButton(R.string.delete, (d, which) -> {
                    if (db.deleteItem(item.getId())) {
                        toast(R.string.item_deleted);
                        loadItems();
                    } else {
                        toast(R.string.error_deleting_item);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    /** Shows errors directly on the fields and returns true only if both are valid. */
    private boolean isValid(EditText nameField, String name, EditText qtyField, String qtyText) {
        String nameError = ValidationUtils.validateItemName(name);
        String qtyError = ValidationUtils.validateQuantity(qtyText);
        nameField.setError(nameError);
        qtyField.setError(qtyError);
        return nameError == null && qtyError == null;
    }

    private void toast(int messageRes) {
        Toast.makeText(this, messageRes, Toast.LENGTH_SHORT).show();
    }
}
