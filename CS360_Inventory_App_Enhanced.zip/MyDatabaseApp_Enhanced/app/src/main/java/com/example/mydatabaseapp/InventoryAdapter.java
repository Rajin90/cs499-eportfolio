package com.example.mydatabaseapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Turns InventoryItem objects into list rows.
 *
 * CS 499 enhancement: the original activity built display strings itself and
 * threw away the database ID. Display logic now lives here, and the list
 * holds real InventoryItem objects, so a tapped row gives back its ID.
 */
public class InventoryAdapter extends ArrayAdapter<InventoryItem> {

    private final LayoutInflater inflater;

    public InventoryAdapter(Context context, List<InventoryItem> items) {
        super(context, 0, items);
        inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        if (row == null) {
            row = inflater.inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        InventoryItem item = getItem(position);
        TextView title = row.findViewById(android.R.id.text1);
        TextView subtitle = row.findViewById(android.R.id.text2);

        if (item != null) {
            title.setText(item.getName());
            if (item.isOutOfStock()) {
                subtitle.setText(getContext().getString(R.string.out_of_stock));
            } else {
                subtitle.setText(getContext().getString(R.string.quantity_format, item.getQuantity()));
            }
        }
        return row;
    }

    @Override
    public long getItemId(int position) {
        InventoryItem item = getItem(position);
        return item == null ? -1 : item.getId();
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}
