package com.example.mydatabaseapp;

/**
 * Model class for one row of the items table.
 *
 * CS 499 enhancement: the original app stored each item only as a display
 * string ("Name - Qty: 5"), so the real database ID was lost after loading.
 * Keeping the ID with the item lets update and delete target the correct row.
 */
public class InventoryItem {

    private final long id;
    private final String name;
    private final int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public boolean isOutOfStock() {
        return quantity == 0;
    }
}
