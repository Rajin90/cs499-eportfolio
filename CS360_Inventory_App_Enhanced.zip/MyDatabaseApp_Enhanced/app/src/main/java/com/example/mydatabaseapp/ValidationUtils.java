package com.example.mydatabaseapp;

/**
 * Central place for every input rule in the app.
 *
 * CS 499 enhancement: the original activities had no validation at all
 * (an empty quantity crashed the app with NumberFormatException). Putting the
 * rules here keeps them out of the UI code and makes them unit-testable on
 * the JVM, because this class has no Android dependencies.
 *
 * Each method returns null when the input is valid, or a user-facing error
 * message when it is not.
 */
public final class ValidationUtils {

    public static final int USERNAME_MIN = 3;
    public static final int USERNAME_MAX = 20;
    public static final int PASSWORD_MIN = 8;
    public static final int ITEM_NAME_MAX = 50;
    public static final int QUANTITY_MAX = 100_000;

    private ValidationUtils() {
        // utility class, no instances
    }

    public static String validateUsername(String username) {
        String value = username == null ? "" : username.trim();
        if (value.isEmpty()) {
            return "Username is required";
        }
        if (value.length() < USERNAME_MIN || value.length() > USERNAME_MAX) {
            return "Username must be " + USERNAME_MIN + "-" + USERNAME_MAX + " characters";
        }
        if (!value.matches("[A-Za-z0-9_]+")) {
            return "Username can only contain letters, numbers, and underscores";
        }
        return null;
    }

    /** Used at registration, where the password rules are enforced. */
    public static String validateNewPassword(String password) {
        if (password == null || password.isEmpty()) {
            return "Password is required";
        }
        if (password.length() < PASSWORD_MIN) {
            return "Password must be at least " + PASSWORD_MIN + " characters";
        }
        boolean hasLetter = false;
        boolean hasDigit = false;
        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) hasLetter = true;
            if (Character.isDigit(c)) hasDigit = true;
        }
        if (!hasLetter || !hasDigit) {
            return "Password must contain at least one letter and one number";
        }
        return null;
    }

    /** Used at login, where we only check that something was typed. */
    public static String validateLoginPassword(String password) {
        if (password == null || password.isEmpty()) {
            return "Password is required";
        }
        return null;
    }

    public static String validateItemName(String name) {
        String value = name == null ? "" : name.trim();
        if (value.isEmpty()) {
            return "Item name is required";
        }
        if (value.length() > ITEM_NAME_MAX) {
            return "Item name must be " + ITEM_NAME_MAX + " characters or fewer";
        }
        return null;
    }

    public static String validateQuantity(String quantityText) {
        String value = quantityText == null ? "" : quantityText.trim();
        if (value.isEmpty()) {
            return "Quantity is required";
        }
        int quantity;
        try {
            quantity = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return "Quantity must be a whole number";
        }
        if (quantity < 0) {
            return "Quantity cannot be negative";
        }
        if (quantity > QUANTITY_MAX) {
            return "Quantity cannot be more than " + QUANTITY_MAX;
        }
        return null;
    }

    /** Call only after validateQuantity(...) returned null. */
    public static int parseQuantity(String quantityText) {
        return Integer.parseInt(quantityText.trim());
    }
}
