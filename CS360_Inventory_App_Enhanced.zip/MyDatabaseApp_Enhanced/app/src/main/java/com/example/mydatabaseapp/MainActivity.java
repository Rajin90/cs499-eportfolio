package com.example.mydatabaseapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Login and registration screen.
 *
 * CS 499 enhancements:
 *  - Username and password are validated before any database call.
 *  - Registration reports "username taken" instead of a generic "Error",
 *    and the database now rejects duplicate usernames.
 *  - Passwords are hashed (see PasswordHasher / DatabaseHelper), and the
 *    password field is masked in the layout.
 *  - The password field is cleared after a login attempt.
 */
public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        Button loginBtn = findViewById(R.id.loginBtn);
        Button registerBtn = findViewById(R.id.registerBtn);

        db = new DatabaseHelper(this);

        registerBtn.setOnClickListener(v -> register());
        loginBtn.setOnClickListener(v -> login());
    }

    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }

    private void register() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        String usernameError = ValidationUtils.validateUsername(username);
        String passwordError = ValidationUtils.validateNewPassword(password);
        usernameInput.setError(usernameError);
        passwordInput.setError(passwordError);
        if (usernameError != null || passwordError != null) {
            return;
        }

        switch (db.registerUser(username, password)) {
            case SUCCESS:
                toast(R.string.user_registered);
                passwordInput.setText("");
                break;
            case USERNAME_TAKEN:
                usernameInput.setError(getString(R.string.username_taken));
                break;
            default:
                toast(R.string.registration_failed);
                break;
        }
    }

    private void login() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        // At login only check that fields are filled in; the full rules apply at registration
        String usernameError = username.trim().isEmpty() ? getString(R.string.username_required) : null;
        String passwordError = ValidationUtils.validateLoginPassword(password);
        usernameInput.setError(usernameError);
        passwordInput.setError(passwordError);
        if (usernameError != null || passwordError != null) {
            return;
        }

        boolean valid = db.authenticate(username, password);
        passwordInput.setText("");

        if (valid) {
            toast(R.string.login_successful);
            startActivity(new Intent(MainActivity.this, InventoryActivity.class));
        } else {
            // Same message for unknown user and wrong password, so the screen
            // does not reveal which usernames exist
            toast(R.string.invalid_login);
        }
    }

    private void toast(int messageRes) {
        Toast.makeText(this, messageRes, Toast.LENGTH_SHORT).show();
    }
}
