package com.example.mydatabaseapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Data-access layer for the app. All SQL lives here; the activities never
 * build queries or read cursors themselves.
 *
 * CS 499 enhancements compared with the original version 1:
 *  - Schema version 2 adds constraints (NOT NULL, UNIQUE username, quantity >= 0).
 *  - Passwords are stored as salted PBKDF2 hashes instead of plain text.
 *  - onUpgrade migrates existing v1 data instead of doing nothing.
 *  - Added updateItem; deleteItem/updateItem use the real row ID.
 *  - Every Cursor is closed (try-with-resources).
 *  - Each operation logs its elapsed time under the CS499_DB_PERF tag so the
 *    performance can be measured in Logcat.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "InventoryDB";
    public static final int DB_VERSION = 2;

    private static final String TAG = "DatabaseHelper";
    private static final String PERF_TAG = "CS499_DB_PERF";

    // Table and column names (avoids typos in repeated string literals)
    static final String TABLE_USERS = "users";
    static final String COL_USER_ID = "id";
    static final String COL_USERNAME = "username";
    static final String COL_PASSWORD_HASH = "password_hash";
    static final String COL_SALT = "salt";

    static final String TABLE_ITEMS = "items";
    static final String COL_ITEM_ID = "id";
    static final String COL_ITEM_NAME = "name";
    static final String COL_QUANTITY = "quantity";

    private static final String CREATE_USERS_V2 =
            "CREATE TABLE " + TABLE_USERS + " ("
                    + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                    + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                    + COL_SALT + " TEXT NOT NULL)";

    private static final String CREATE_ITEMS_V2 =
            "CREATE TABLE " + TABLE_ITEMS + " ("
                    + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COL_ITEM_NAME + " TEXT NOT NULL, "
                    + COL_QUANTITY + " INTEGER NOT NULL CHECK (" + COL_QUANTITY + " >= 0))";

    private static final String CREATE_ITEMS_NAME_INDEX =
            "CREATE INDEX IF NOT EXISTS idx_items_name ON " + TABLE_ITEMS
                    + " (" + COL_ITEM_NAME + " COLLATE NOCASE)";

    public enum RegisterResult { SUCCESS, USERNAME_TAKEN, ERROR }

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS_V2);
        db.execSQL(CREATE_ITEMS_V2);
        db.execSQL(CREATE_ITEMS_NAME_INDEX);
    }

    /**
     * Version 1 -> 2 migration. Android runs onUpgrade inside a transaction,
     * so if any step fails the whole upgrade is rolled back.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            migrateUsersToV2(db);
            migrateItemsToV2(db);
        }
    }

    private void migrateUsersToV2(SQLiteDatabase db) {
        db.execSQL("ALTER TABLE users RENAME TO users_v1");
        db.execSQL(CREATE_USERS_V2);

        try (Cursor cursor = db.rawQuery(
                "SELECT username, password FROM users_v1 ORDER BY id", null)) {
            while (cursor.moveToNext()) {
                String username = cursor.isNull(0) ? "" : cursor.getString(0).trim();
                String plainPassword = cursor.isNull(1) ? "" : cursor.getString(1);
                if (username.isEmpty() || plainPassword.isEmpty()) {
                    continue; // v1 allowed blank accounts; they cannot be logged into safely
                }
                String salt = PasswordHasher.generateSalt();
                ContentValues cv = new ContentValues();
                cv.put(COL_USERNAME, username);
                cv.put(COL_PASSWORD_HASH, PasswordHasher.hash(plainPassword, salt));
                cv.put(COL_SALT, salt);
                // v1 allowed duplicate usernames; keep the first, skip the rest
                db.insertWithOnConflict(TABLE_USERS, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
            }
        }
        db.execSQL("DROP TABLE users_v1");
    }

    private void migrateItemsToV2(SQLiteDatabase db) {
        db.execSQL("ALTER TABLE items RENAME TO items_v1");
        db.execSQL(CREATE_ITEMS_V2);
        // Keep the original IDs; repair rows that would break the new constraints
        db.execSQL("INSERT INTO items (id, name, quantity) "
                + "SELECT id, "
                + "COALESCE(NULLIF(TRIM(name), ''), 'Unnamed item'), "
                + "MAX(COALESCE(quantity, 0), 0) "
                + "FROM items_v1");
        db.execSQL("DROP TABLE items_v1");
        db.execSQL(CREATE_ITEMS_NAME_INDEX);
    }

    // ---------------------------------------------------------------- users

    public RegisterResult registerUser(String username, String password) {
        long start = System.nanoTime();
        try {
            if (usernameExists(username)) {
                return RegisterResult.USERNAME_TAKEN;
            }
            String salt = PasswordHasher.generateSalt();
            ContentValues cv = new ContentValues();
            cv.put(COL_USERNAME, username.trim());
            cv.put(COL_PASSWORD_HASH, PasswordHasher.hash(password, salt));
            cv.put(COL_SALT, salt);
            long rowId = getWritableDatabase().insert(TABLE_USERS, null, cv);
            return rowId == -1 ? RegisterResult.ERROR : RegisterResult.SUCCESS;
        } catch (SQLException e) {
            Log.e(TAG, "registerUser failed", e);
            return RegisterResult.ERROR;
        } finally {
            logElapsed("registerUser", start);
        }
    }

    public boolean usernameExists(String username) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + " = ?",
                new String[]{username.trim()},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    public boolean authenticate(String username, String password) {
        long start = System.nanoTime();
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{COL_PASSWORD_HASH, COL_SALT},
                COL_USERNAME + " = ?",
                new String[]{username.trim()},
                null, null, null)) {
            if (!cursor.moveToFirst()) {
                return false;
            }
            return PasswordHasher.verify(password, cursor.getString(1), cursor.getString(0));
        } finally {
            logElapsed("authenticate", start);
        }
    }

    // ---------------------------------------------------------------- items

    /** @return the new row ID, or -1 if the insert failed */
    public long addItem(String name, int quantity) {
        long start = System.nanoTime();
        try {
            ContentValues cv = new ContentValues();
            cv.put(COL_ITEM_NAME, name.trim());
            cv.put(COL_QUANTITY, quantity);
            return getWritableDatabase().insert(TABLE_ITEMS, null, cv);
        } catch (SQLException e) {
            Log.e(TAG, "addItem failed", e);
            return -1;
        } finally {
            logElapsed("addItem", start);
        }
    }

    public List<InventoryItem> getAllItems() {
        long start = System.nanoTime();
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_ITEMS,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_QUANTITY},
                null, null, null, null,
                COL_ITEM_NAME + " COLLATE NOCASE ASC")) {
            int idIndex = cursor.getColumnIndexOrThrow(COL_ITEM_ID);
            int nameIndex = cursor.getColumnIndexOrThrow(COL_ITEM_NAME);
            int qtyIndex = cursor.getColumnIndexOrThrow(COL_QUANTITY);
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(idIndex),
                        cursor.getString(nameIndex),
                        cursor.getInt(qtyIndex)));
            }
        } finally {
            logElapsed("getAllItems (" + items.size() + " rows)", start);
        }
        return items;
    }

    public boolean updateItem(long id, String name, int quantity) {
        long start = System.nanoTime();
        try {
            ContentValues cv = new ContentValues();
            cv.put(COL_ITEM_NAME, name.trim());
            cv.put(COL_QUANTITY, quantity);
            int rows = getWritableDatabase().update(
                    TABLE_ITEMS, cv, COL_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
            return rows == 1;
        } catch (SQLException e) {
            Log.e(TAG, "updateItem failed", e);
            return false;
        } finally {
            logElapsed("updateItem", start);
        }
    }

    public boolean deleteItem(long id) {
        long start = System.nanoTime();
        try {
            int rows = getWritableDatabase().delete(
                    TABLE_ITEMS, COL_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
            return rows == 1;
        } catch (SQLException e) {
            Log.e(TAG, "deleteItem failed", e);
            return false;
        } finally {
            logElapsed("deleteItem", start);
        }
    }

    private static void logElapsed(String operation, long startNanos) {
        double ms = (System.nanoTime() - startNanos) / 1_000_000.0;
        Log.d(PERF_TAG, String.format(java.util.Locale.US, "%s took %.2f ms", operation, ms));
    }
}
