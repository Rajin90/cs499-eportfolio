package com.example.mydatabaseapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    EditText itemName, itemQty;
    Button addBtn;
    ListView listView;
    DatabaseHelper db;

    ArrayList<String> list;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        itemName = findViewById(R.id.itemName);
        itemQty = findViewById(R.id.itemQty);
        addBtn = findViewById(R.id.addBtn);
        listView = findViewById(R.id.listView);

        db = new DatabaseHelper(this);

        loadData();

        addBtn.setOnClickListener(v -> {
            String name = itemName.getText().toString();
            int qty = Integer.parseInt(itemQty.getText().toString());

            db.insertItem(name, qty);
            loadData();
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            db.deleteItem(position + 1);
            loadData();
            return true;
        });
    }

    private void loadData() {
        list = new ArrayList<>();
        Cursor cursor = db.getItems();

        while (cursor.moveToNext()) {
            list.add(cursor.getString(1) + " - Qty: " + cursor.getInt(2));
        }

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, list);

        listView.setAdapter(adapter);
    }
}